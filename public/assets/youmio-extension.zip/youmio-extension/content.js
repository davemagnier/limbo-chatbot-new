console.log('Youmio Verify Extension Loaded!');

// Storage for verified items
let verifiedMessages = JSON.parse(localStorage.getItem('youmio_verifications') || '[]');

// Youmio Brand Colors - Matching your subscription UI
const YOUMIO_COLORS = {
    // Muted gradient like your subscription buttons
    primary: 'linear-gradient(135deg, #C668A8 0%, #A668C4 100%)',
    primaryHover: 'linear-gradient(135deg, #B55898 0%, #9658B4 100%)',
    
    // Individual colors
    pink: '#C668A8',
    pinkDark: '#B55898',
    purple: '#A668C4',
    purpleDark: '#9658B4',
    
    // UI colors
    dark: '#1F1F2E',
    darker: '#16161D',
    light: '#FFFFFF',
    gray: '#94969C',
    grayLight: '#B8BAC0'
};

// Add Youmio styles
const styleSheet = document.createElement('style');
styleSheet.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    
    @keyframes youmioSlideIn {
        from {
            transform: translateY(-20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    .youmio-verify-btn {
        background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
        font-weight: 600;
        letter-spacing: -0.01em;
        border-radius: 30px;
        position: relative;
        overflow: hidden;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 2px 8px rgba(166, 104, 196, 0.15);
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    
    .youmio-verify-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(166, 104, 196, 0.25);
        background: linear-gradient(135deg, #B55898 0%, #9658B4 100%);
    }
    
    .youmio-icon {
        width: 20px !important;
        height: 20px !important;
        object-fit: contain !important;
        flex-shrink: 0 !important;
        display: inline-block !important;
        vertical-align: middle !important;
    }
    
    .youmio-icon-inverted {
        filter: brightness(0) invert(1);
    }
`;
document.head.appendChild(styleSheet);

// Check if element is an AI assistant message
function isAssistantMessage(element) {
    // Check for Claude/ChatGPT messages
    if (element.classList.contains('font-claude-response')) return true;
    if (element.querySelector('.font-claude-response')) return true;
    if (element.getAttribute('data-message-author-role') === 'assistant') return true;
    if (element.getAttribute('data-from') === 'assistant') return true;
    
    // IMPORTANT: Check for Limbo chatbot messages
    if (element.classList && element.classList.contains('assistant')) return true;
    if (element.closest('.message.assistant')) return true;
    
    // Check parent elements
    let parent = element.parentElement;
    let depth = 0;
    while (parent && depth < 5) {
        if (parent.getAttribute('data-message-author-role') === 'assistant') return true;
        if (parent.getAttribute('data-from') === 'assistant') return true;
        if (parent.classList && parent.classList.contains('assistant')) return true;
        parent = parent.parentElement;
        depth++;
    }
    
    // Check for other AI assistant indicators
    if (element.className && (
        element.className.includes('assistant') ||
        element.className.includes('bot-message') ||
        element.className.includes('ai-message')
    )) return true;
    
    // Exclude user messages
    if (element.getAttribute('data-message-author-role') === 'user') return false;
    if (element.getAttribute('data-from') === 'human') return false;
    if (element.className && element.className.includes('user')) return false;
    
    return false;
}

// Check if it's specifically a Limbo message
function isLimboMessage(element) {
    // Check if we're in an iframe with Limbo chatbot
    if (window.location.href.includes('limbo-chatbot.html')) return true;
    
    // Check for Limbo-specific identifiers
    const label = element.querySelector('.message-label');
    if (label && label.textContent === 'Limbo') return true;
    
    // Check parent for Limbo context
    const chatContainer = element.closest('.chat-container');
    if (chatContainer) {
        const header = chatContainer.querySelector('.header-title');
        if (header && header.textContent === 'Limbo') return true;
    }
    
    return false;
}

// Add verify button to element with Youmio branding
function addVerifyButtonToElement(element) {
    if (element.querySelector('.youmio-verify-btn')) return false;
    if (!isAssistantMessage(element)) return false;
    
    const button = document.createElement('button');
    button.className = 'youmio-verify-btn';
    
    // Check if this is a Limbo message for special handling
    const isLimbo = isLimboMessage(element);
    
    button.innerHTML = `
        <span style="
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            position: relative;
        ">
            <img src="${chrome.runtime.getURL('icon48.png')}" 
                 class="youmio-icon youmio-icon-inverted"
                 alt="">
            <span style="
                font-weight: 600;
                font-size: 14px;
                line-height: 1;
            ">Mint to Chain</span>
        </span>
    `;
    
    button.style.cssText = `
        background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 30px;
        margin: 12px 0;
        cursor: pointer;
        font-weight: 600;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 2px 8px rgba(166, 104, 196, 0.15);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        letter-spacing: -0.01em;
        position: relative;
        overflow: hidden;
        min-width: 160px;
    `;
    
    button.onclick = async function() {
        const originalContent = button.innerHTML;
        
        // Minting state
        button.innerHTML = `
            <span style="
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                width: 100%;
            ">
                <span style="
                    display: inline-block;
                    width: 16px;
                    height: 16px;
                    border: 2px solid white;
                    border-top-color: transparent;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                "></span>
                <span style="font-weight: 600; line-height: 1;">Minting...</span>
            </span>
        `;
        button.disabled = true;
        button.style.opacity = '0.9';
        
        // Simulate blockchain verification
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Generate mock transaction data
        const messageText = element.innerText || '';
        const txHash = '0x' + Math.random().toString(16).slice(2, 10);
        const mockWallet = '0x742d...8Db9';
        const messageType = isLimbo ? 'Limbo AI' : 'AI Assistant';
        
        // Save to storage
        const verifyData = {
            message: messageText.substring(0, 200),
            txHash: txHash,
            wallet: mockWallet,
            timestamp: new Date().toISOString(),
            url: window.location.href,
            type: messageType
        };
        
        verifiedMessages.push(verifyData);
        localStorage.setItem('youmio_verifications', JSON.stringify(verifiedMessages));
        
        // Success state
        button.innerHTML = `
            <span style="
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                width: 100%;
            ">
                <span style="font-size: 16px;">✨</span>
                <span style="font-weight: 600; line-height: 1;">Minted!</span>
            </span>
        `;
        button.style.background = 'linear-gradient(135deg, #4BBFEB 0%, #5B8DEE 100%)';
        
        // Create Youmio-styled success notification
        const successDiv = document.createElement('div');
        successDiv.className = 'youmio-success-notification';
        successDiv.style.cssText = `
            position: fixed;
            top: 24px;
            right: 24px;
            background: #1F1F2E;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255,255,255,0.05) inset;
            z-index: 100000;
            max-width: 360px;
            animation: youmioSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            color: white;
        `;
        
        successDiv.innerHTML = `
            <div style="display: flex; align-items: flex-start; gap: 14px;">
                <div style="
                    width: 44px; 
                    height: 44px; 
                    background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                    border-radius: 12px; 
                    display: flex; 
                    align-items: center; 
                    justify-content: center;
                    flex-shrink: 0;
                ">
                    <img src="${chrome.runtime.getURL('icon48.png')}" 
                         style="width: 26px; height: 26px; object-fit: contain; filter: brightness(0) invert(1);" 
                         alt="">
                </div>
                <div style="flex: 1;">
                    <h3 style="margin: 0 0 4px 0; font-size: 16px; font-weight: 600;">Successfully Minted to Chain!</h3>
                    <p style="margin: 0 0 12px 0; font-size: 13px; color: #94969C;">Youmio Testnet${isLimbo ? ' • Limbo AI' : ''}</p>
                    
                    <div style="
                        background: rgba(255, 255, 255, 0.03); 
                        border-radius: 10px; 
                        padding: 10px;
                        border: 1px solid rgba(255, 255, 255, 0.05);
                    ">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                            <span style="font-size: 12px; color: #94969C;">Transaction</span>
                            <span style="font-size: 12px; font-family: monospace; color: #C668A8;">${txHash}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="font-size: 12px; color: #94969C;">Total Verifications</span>
                            <span style="font-size: 12px; font-weight: 600; color: white;">${verifiedMessages.length}</span>
                        </div>
                    </div>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" style="
                    background: transparent;
                    border: none;
                    color: #94969C;
                    cursor: pointer;
                    padding: 0;
                    font-size: 20px;
                    line-height: 1;
                    transition: color 0.2s;
                " onmouseover="this.style.color='white'" onmouseout="this.style.color='#94969C'">
                    ×
                </button>
            </div>
        `;
        
        document.body.appendChild(successDiv);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (successDiv.parentElement) {
                successDiv.style.animation = 'youmioSlideIn 0.3s reverse';
                setTimeout(() => successDiv.remove(), 300);
            }
        }, 5000);
        
        // Reset button
        setTimeout(() => {
            button.innerHTML = originalContent;
            button.disabled = false;
            button.style.opacity = '1';
            button.style.background = 'linear-gradient(135deg, #C668A8 0%, #A668C4 100%)';
        }, 2000);
    };
    
    element.appendChild(button);
    return true;
}

// Add buttons to messages
function addVerifyButtons() {
    const selectors = [
        '.font-claude-response',
        '[data-message-author-role="assistant"]',
        '[data-from="assistant"]',
        '.assistant-message',
        '.bot-message',
        '.ai-message',
        '.message.assistant' // For Limbo chatbot
    ];
    
    let addedCount = 0;
    
    selectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            const text = element.innerText || '';
            if (text.length > 20 && !element.querySelector('.youmio-verify-btn')) {
                if (addVerifyButtonToElement(element)) {
                    addedCount++;
                }
            }
        });
    });
    
    // Also check iframes for Limbo chatbot
    const iframes = document.querySelectorAll('iframe');
    iframes.forEach(iframe => {
        try {
            if (iframe.src && iframe.src.includes('limbo-chatbot.html')) {
                const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                const limboMessages = iframeDoc.querySelectorAll('.message.assistant');
                limboMessages.forEach(element => {
                    const text = element.innerText || '';
                    if (text.length > 20 && !element.querySelector('.youmio-verify-btn')) {
                        addVerifyButtonToElement(element);
                    }
                });
            }
        } catch (e) {
            // Iframe cross-origin security - that's okay
        }
    });
    
    return addedCount;
}

// Add Youmio dashboard button
function addDashboard() {
    if (document.getElementById('youmio-dashboard')) {
        const dashBtn = document.getElementById('youmio-dashboard');
        dashBtn.innerHTML = `
            <span style="
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                width: 100%;
            ">
                <img src="${chrome.runtime.getURL('icon48.png')}" 
                     class="youmio-icon youmio-icon-inverted"
                     alt="">
                <span style="font-weight: 600; line-height: 1;">View on Chain Verifications (${verifiedMessages.length})</span>
            </span>
        `;
        return;
    }
    
    const dashBtn = document.createElement('button');
    dashBtn.id = 'youmio-dashboard';
    dashBtn.innerHTML = `
        <span style="
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
        ">
            <img src="${chrome.runtime.getURL('icon48.png')}" 
                 class="youmio-icon youmio-icon-inverted"
                 alt="">
            <span style="font-weight: 600; line-height: 1;">View on Chain Verifications (${verifiedMessages.length})</span>
        </span>
    `;
    dashBtn.style.cssText = `
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 99999;
        background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
        color: white;
        padding: 14px 24px;
        border: none;
        border-radius: 50px;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        box-shadow: 0 4px 16px rgba(166, 104, 196, 0.2);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        letter-spacing: -0.01em;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 240px;
    `;
    
    dashBtn.onmouseover = () => {
        dashBtn.style.transform = 'translateY(-2px)';
        dashBtn.style.boxShadow = '0 6px 20px rgba(166, 104, 196, 0.3)';
        dashBtn.style.background = 'linear-gradient(135deg, #B55898 0%, #9658B4 100%)';
    };
    
    dashBtn.onmouseout = () => {
        dashBtn.style.transform = 'translateY(0)';
        dashBtn.style.boxShadow = '0 4px 16px rgba(166, 104, 196, 0.2)';
        dashBtn.style.background = 'linear-gradient(135deg, #C668A8 0%, #A668C4 100%)';
    };
    
    dashBtn.onclick = () => {
        // Dashboard modal code
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(22, 22, 29, 0.95);
            backdrop-filter: blur(10px);
            z-index: 100001;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        `;
        
        const content = document.createElement('div');
        content.style.cssText = `
            background: #1F1F2E;
            border-radius: 20px;
            padding: 32px;
            max-width: 720px;
            width: 90%;
            max-height: 85vh;
            overflow-y: auto;
            position: relative;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            color: white;
        `;
        
        const verificationsHTML = verifiedMessages.length > 0 
            ? verifiedMessages.map((verify, i) => `
                <div style="
                    background: rgba(255, 255, 255, 0.03);
                    border: 1px solid rgba(255, 255, 255, 0.06);
                    border-radius: 16px;
                    padding: 20px;
                    margin-bottom: 16px;
                    transition: all 0.3s;
                    cursor: pointer;
                " onmouseover="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.transform='translateX(4px)'" 
                   onmouseout="this.style.background='rgba(255, 255, 255, 0.03)'; this.style.transform='translateX(0)'">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <span style="
                            background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                            color: white;
                            padding: 6px 14px;
                            border-radius: 20px;
                            font-size: 12px;
                            font-weight: 600;
                        ">Verification #${i + 1}${verify.type ? ' • ' + verify.type : ''}</span>
                        <span style="font-size: 12px; color: #94969C;">${new Date(verify.timestamp).toLocaleString()}</span>
                    </div>
                    <div style="font-size: 12px; color: #C668A8; margin-bottom: 12px; font-family: monospace;">
                        TX: ${verify.txHash}
                    </div>
                    <div style="
                        background: rgba(0, 0, 0, 0.2);
                        padding: 14px;
                        border-radius: 10px;
                        font-size: 14px;
                        color: #E0E0E0;
                        line-height: 1.6;
                    ">
                        ${verify.message.substring(0, 150)}...
                    </div>
                </div>
            `).join('')
            : `
                <div style="
                    text-align: center;
                    padding: 80px 20px;
                ">
                    <div style="
                        width: 100px;
                        height: 100px;
                        margin: 0 auto 24px;
                        background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                        border-radius: 24px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    ">
                        <img src="${chrome.runtime.getURL('icon128.png')}" 
                             style="width: 60px; height: 60px; object-fit: contain; filter: brightness(0) invert(1);" 
                             alt="">
                    </div>
                    <h3 style="font-size: 20px; margin-bottom: 8px; font-weight: 600;">No Messages Minted Yet</h3>
                    <p style="font-size: 14px; color: #94969C;">Click "Mint to Chain" on any AI message to get started!</p>
                </div>
            `;
        
        content.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px;">
                <div style="display: flex; align-items: center; gap: 16px;">
                    <img src="${chrome.runtime.getURL('icon128.png')}" 
                         style="width: 48px; height: 48px; border-radius: 12px; object-fit: contain;" 
                         alt="Youmio">
                    <div>
                        <h2 style="margin: 0; font-size: 24px; font-weight: 700;">Youmio Verify Dashboard</h2>
                        <p style="margin: 4px 0 0 0; color: #94969C; font-size: 14px;">Blockchain Verification System</p>
                    </div>
                </div>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="
                    background: rgba(255, 255, 255, 0.05);
                    border: none;
                    width: 36px;
                    height: 36px;
                    border-radius: 10px;
                    cursor: pointer;
                    font-size: 20px;
                    color: #94969C;
                    transition: all 0.2s;
                " onmouseover="this.style.background='rgba(255, 255, 255, 0.08)'" 
                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'">
                    ×
                </button>
            </div>
            
            <div style="
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                gap: 16px;
                margin-bottom: 32px;
            ">
                <div style="
                    background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                    padding: 20px;
                    border-radius: 16px;
                    color: white;
                ">
                    <div style="font-size: 32px; font-weight: 700;">${verifiedMessages.length}</div>
                    <div style="font-size: 13px; opacity: 0.9; margin-top: 4px;">Total Verifications</div>
                </div>
                <div style="
                    background: linear-gradient(135deg, #7B5CE6 0%, #5B8DEE 100%);
                    padding: 20px;
                    border-radius: 16px;
                    color: white;
                ">
                    <div style="font-size: 32px; font-weight: 700;">✅</div>
                    <div style="font-size: 13px; opacity: 0.9; margin-top: 4px;">Status: Active</div>
                </div>
                <div style="
                    background: rgba(75, 191, 235, 0.1);
                    border: 1px solid rgba(75, 191, 235, 0.2);
                    padding: 20px;
                    border-radius: 16px;
                    color: white;
                ">
                    <div style="font-size: 32px; font-weight: 700;">L1</div>
                    <div style="font-size: 13px; opacity: 0.9; margin-top: 4px;">Youmio Testnet</div>
                </div>
            </div>
            
            <div style="max-height: 400px; overflow-y: auto; padding-right: 8px;">
                ${verificationsHTML}
            </div>
            
            ${verifiedMessages.length > 0 ? `
                <button onclick="
                    if(confirm('Clear all verified messages from local storage?')) {
                        localStorage.removeItem('youmio_verifications');
                        this.parentElement.parentElement.remove();
                        location.reload();
                    }
                " style="
                    margin-top: 24px;
                    padding: 14px 24px;
                    background: transparent;
                    color: #C668A8;
                    border: 1px solid #C668A8;
                    border-radius: 12px;
                    cursor: pointer;
                    width: 100%;
                    font-size: 14px;
                    font-weight: 600;
                    transition: all 0.2s;
                    font-family: 'Inter', sans-serif;
                " onmouseover="this.style.background='rgba(198, 104, 168, 0.1)'" 
                   onmouseout="this.style.background='transparent'">
                    Clear All Verifications
                </button>
            ` : ''}
        `;
        
        modal.appendChild(content);
        document.body.appendChild(modal);
        
        modal.onclick = (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        };
    };
    
    document.body.appendChild(dashBtn);
}

// Initialize
setTimeout(() => {
    addVerifyButtons();
    addDashboard();
    console.log('✅ Youmio Verify Extension Active');
}, 1000);

// Auto-add buttons
setInterval(() => {
    addVerifyButtons();
    addDashboard();
}, 3000);

// Watch for changes
const observer = new MutationObserver(() => {
    setTimeout(addVerifyButtons, 500);
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});