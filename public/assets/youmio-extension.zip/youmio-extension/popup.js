document.addEventListener('DOMContentLoaded', () => {
    // Load verification count from localStorage
    const verifications = JSON.parse(localStorage.getItem('youmio_verifications') || '[]');
    document.getElementById('verifyCount').textContent = verifications.length;
    
    // Open dashboard button - opens the extension's dashboard
    document.getElementById('openDashboard').addEventListener('click', () => {
        // Send message to content script to open dashboard
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0]) {
                // Inject the dashboard opening code into the current tab
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: () => {
                        // Check if dashboard already exists
                        const existingModal = document.getElementById('youmio-dashboard-modal');
                        if (existingModal) {
                            existingModal.remove();
                        }
                        
                        // Get verified messages from localStorage
                        const verifiedMessages = JSON.parse(localStorage.getItem('youmio_verifications') || '[]');
                        
                        // Create dashboard modal
                        const modal = document.createElement('div');
                        modal.id = 'youmio-dashboard-modal';
                        modal.style.cssText = `
                            position: fixed;
                            top: 0;
                            left: 0;
                            right: 0;
                            bottom: 0;
                            background: rgba(22, 22, 29, 0.95);
                            backdrop-filter: blur(10px);
                            z-index: 100001;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            animation: fadeIn 0.3s ease;
                            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
                        `;
                        
                        const content = document.createElement('div');
                        content.style.cssText = `
                            background: #1F1F2E;
                            border-radius: 20px;
                            padding: 32px;
                            max-width: 720px;
                            width: 90%;
                            max-height: 85vh;
                            overflow-y: auto;
                            position: relative;
                            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
                            color: white;
                        `;
                        
                        const verificationsHTML = verifiedMessages.length > 0 
                            ? verifiedMessages.map((verify, i) => `
                                <div style="
                                    background: rgba(255, 255, 255, 0.03);
                                    border: 1px solid rgba(255, 255, 255, 0.06);
                                    border-radius: 16px;
                                    padding: 20px;
                                    margin-bottom: 16px;
                                    transition: all 0.3s;
                                    cursor: pointer;
                                " onmouseover="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.transform='translateX(4px)'" 
                                   onmouseout="this.style.background='rgba(255, 255, 255, 0.03)'; this.style.transform='translateX(0)'">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                                        <span style="
                                            background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                                            color: white;
                                            padding: 6px 14px;
                                            border-radius: 20px;
                                            font-size: 12px;
                                            font-weight: 600;
                                        ">Verification #${i + 1}</span>
                                        <span style="font-size: 12px; color: #94969C;">${new Date(verify.timestamp).toLocaleString()}</span>
                                    </div>
                                    <div style="font-size: 12px; color: #C668A8; margin-bottom: 12px; font-family: monospace;">
                                        TX: ${verify.txHash}
                                    </div>
                                    <div style="
                                        background: rgba(0, 0, 0, 0.2);
                                        padding: 14px;
                                        border-radius: 10px;
                                        font-size: 14px;
                                        color: #E0E0E0;
                                        line-height: 1.6;
                                    ">
                                        ${verify.message.substring(0, 150)}...
                                    </div>
                                </div>
                            `).join('')
                            : `
                                <div style="
                                    text-align: center;
                                    padding: 80px 20px;
                                ">
                                    <div style="
                                        width: 100px;
                                        height: 100px;
                                        margin: 0 auto 24px;
                                        background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                                        border-radius: 24px;
                                        display: flex;
                                        align-items: center;
                                        justify-content: center;
                                        font-size: 48px;
                                    ">
                                        ✓
                                    </div>
                                    <h3 style="font-size: 20px; margin-bottom: 8px; font-weight: 600;">No Messages Verified Yet</h3>
                                    <p style="font-size: 14px; color: #94969C;">Click "Verify on Chain" on any AI message to get started!</p>
                                </div>
                            `;
                        
                        content.innerHTML = `
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px;">
                                <div style="display: flex; align-items: center; gap: 16px;">
                                    <div style="
                                        width: 48px;
                                        height: 48px;
                                        background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                                        border-radius: 12px;
                                        display: flex;
                                        align-items: center;
                                        justify-content: center;
                                        font-size: 24px;
                                        font-weight: bold;
                                        color: white;
                                    ">
                                        Y
                                    </div>
                                    <div>
                                        <h2 style="margin: 0; font-size: 24px; font-weight: 700;">Youmio Verify Dashboard</h2>
                                        <p style="margin: 4px 0 0 0; color: #94969C; font-size: 14px;">Blockchain Verification System</p>
                                    </div>
                                </div>
                                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="
                                    background: rgba(255, 255, 255, 0.05);
                                    border: none;
                                    width: 36px;
                                    height: 36px;
                                    border-radius: 10px;
                                    cursor: pointer;
                                    font-size: 20px;
                                    color: #94969C;
                                    transition: all 0.2s;
                                " onmouseover="this.style.background='rgba(255, 255, 255, 0.08)'" 
                                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'">
                                    ×
                                </button>
                            </div>
                            
                            <div style="
                                display: grid;
                                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                                gap: 16px;
                                margin-bottom: 32px;
                            ">
                                <div style="
                                    background: linear-gradient(135deg, #C668A8 0%, #A668C4 100%);
                                    padding: 20px;
                                    border-radius: 16px;
                                    color: white;
                                ">
                                    <div style="font-size: 32px; font-weight: 700;">${verifiedMessages.length}</div>
                                    <div style="font-size: 13px; opacity: 0.9; margin-top: 4px;">Total Verifications</div>
                                </div>
                                <div style="
                                    background: linear-gradient(135deg, #7B5CE6 0%, #5B8DEE 100%);
                                    padding: 20px;
                                    border-radius: 16px;
                                    color: white;
                                ">
                                    <div style="font-size: 32px; font-weight: 700;">✅</div>
                                    <div style="font-size: 13px; opacity: 0.9; margin-top: 4px;">Status: Active</div>
                                </div>
                                <div style="
                                    background: rgba(75, 191, 235, 0.1);
                                    border: 1px solid rgba(75, 191, 235, 0.2);
                                    padding: 20px;
                                    border-radius: 16px;
                                    color: white;
                                ">
                                    <div style="font-size: 32px; font-weight: 700;">L1</div>
                                    <div style="font-size: 13px; opacity: 0.9; margin-top: 4px;">Youmio Testnet</div>
                                </div>
                            </div>
                            
                            <div style="max-height: 400px; overflow-y: auto; padding-right: 8px;">
                                ${verificationsHTML}
                            </div>
                            
                            ${verifiedMessages.length > 0 ? `
                                <button onclick="
                                    if(confirm('Clear all verified messages from local storage?')) {
                                        localStorage.removeItem('youmio_verifications');
                                        this.parentElement.parentElement.remove();
                                        location.reload();
                                    }
                                " style="
                                    margin-top: 24px;
                                    padding: 14px 24px;
                                    background: transparent;
                                    color: #C668A8;
                                    border: 1px solid #C668A8;
                                    border-radius: 12px;
                                    cursor: pointer;
                                    width: 100%;
                                    font-size: 14px;
                                    font-weight: 600;
                                    transition: all 0.2s;
                                    font-family: 'Inter', sans-serif;
                                " onmouseover="this.style.background='rgba(198, 104, 168, 0.1)'" 
                                   onmouseout="this.style.background='transparent'">
                                    Clear All Verifications
                                </button>
                            ` : ''}
                        `;
                        
                        modal.appendChild(content);
                        document.body.appendChild(modal);
                        
                        // Add CSS animation if not already present
                        if (!document.getElementById('youmio-dashboard-styles')) {
                            const style = document.createElement('style');
                            style.id = 'youmio-dashboard-styles';
                            style.textContent = `
                                @keyframes fadeIn {
                                    from { opacity: 0; }
                                    to { opacity: 1; }
                                }
                            `;
                            document.head.appendChild(style);
                        }
                        
                        // Close on background click
                        modal.onclick = (e) => {
                            if (e.target === modal) {
                                modal.remove();
                            }
                        };
                    }
                });
                
                // Close the popup after opening dashboard
                window.close();
            }
        });
    });
});