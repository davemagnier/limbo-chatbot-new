// This file helps connect to MetaMask
(function() {
    // Wait for MetaMask to be available
    if (typeof window.ethereum !== 'undefined') {
        console.log('MetaMask detected by injector!');
        
        // Create a global function for minting
        window.mintWithMetaMask = async function(messageText) {
            try {
                const accounts = await window.ethereum.request({ 
                    method: 'eth_requestAccounts' 
                });
                
                if (accounts.length > 0) {
                    // In production, this would send a real transaction
                    console.log('Would mint:', messageText);
                    console.log('From account:', accounts[0]);
                    
                    return {
                        success: true,
                        account: accounts[0],
                        message: 'Minted successfully!'
                    };
                }
            } catch (error) {
                console.error('MetaMask error:', error);
                return {
                    success: false,
                    error: error.message
                };
            }
        };
    } else {
        console.log('MetaMask not found by injector');
        window.mintWithMetaMask = async function() {
            return {
                success: false,
                error: 'MetaMask not installed'
            };
        };
    }
})();