// Don't use inline scripts, create and append instead
function injectMetaMaskBridge() {
    // Check if already injected
    if (document.getElementById('youmio-bridge')) return;
    
    const script = document.createElement('script');
    script.id = 'youmio-bridge';
    script.src = chrome.runtime.getURL('bridge.js');
    (document.head || document.documentElement).appendChild(script);
}

// Try injection multiple times
injectMetaMaskBridge();
setTimeout(injectMetaMaskBridge, 1000);
setTimeout(injectMetaMaskBridge, 2000);

// Also try direct window access
if (typeof window.ethereum !== 'undefined') {
    console.log('MetaMask found directly!');
    window.hasMetaMask = true;
} else {
    console.log('MetaMask not found directly');
    window.hasMetaMask = false;
}