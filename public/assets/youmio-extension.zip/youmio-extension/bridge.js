// This runs in the page context
if (typeof window.ethereum !== 'undefined') {
    window.web3Enabled = true;
    console.log('Bridge: MetaMask detected!');
    
    // Create connection function
    window.connectMetaMask = async function() {
        try {
            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            return accounts[0];
        } catch (error) {
            throw error;
        }
    };
} else {
    window.web3Enabled = false;
    console.log('Bridge: No MetaMask');
}